from django.apps import AppConfig


class JogadorConfig(AppConfig):
    name = 'jogador'
