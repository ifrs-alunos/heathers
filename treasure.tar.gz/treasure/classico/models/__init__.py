#aqui se importa os arquivos .py
from .base import *
from .post import *
from .link import *
from .arquivo import *
from .comentario import *
