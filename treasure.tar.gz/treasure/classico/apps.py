from django.apps import AppConfig


class ClassicoConfig(AppConfig):
    name = 'classico'
